﻿namespace MonsterClicker.Creatures
{
    public enum MonsterNames
    {
        Wispsnare,
        Cindercrackle,
        Ashwing,
        Shadestep,
        HollowFace,
        MadDeformity,
        ElectricMutt,
        TitaniumThunderLizard,
        ViciousShadowSnake,
        ChaoticGrieveBull,
        Rottingmask,
        Stenchghoul,
        Murkpest,
        Brineteeth,
        Shadefiend,
        Spectralbody,
        Gallsword,
        Decaycrackle
    }
}