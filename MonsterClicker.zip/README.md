# MonsterClicker
C# OOP Teamwork
## Team Members
 - Yulian_Teofilov
 - Borislav_Peev
 - Desislav_A
 - kristiankanchev
 - kremena04
 - Yordan_Paskov
 - RightWing

## Description

Link to design document:

https://docs.google.com/spreadsheets/d/1HJaYc7608DN9zbz-IiaXUIQul9UrK9vwg66S_LnS0Jk/edit?usp=sharing

![titleScreen](https://github.com/Barrelrolla/MonsterClicker/blob/master/Pictures/title.png)

## GitHub Commits

![commits](https://github.com/Barrelrolla/MonsterClicker/blob/master/Pictures/commits.png)

## Class Diagram

![classDiagram](https://github.com/Barrelrolla/MonsterClicker/blob/master/Pictures/classDiagramm.png)

## Screenshots

![screenshot](https://github.com/Barrelrolla/MonsterClicker/blob/master/Pictures/screenshot01.png)

![screenshot](https://github.com/Barrelrolla/MonsterClicker/blob/master/Pictures/screenshot02.png)

